import math
import os
import json

FACILITIES_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "facilities.json")

def load_facilities():
    if os.path.exists(FACILITIES_PATH):
        try:
            with open(FACILITIES_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []
    return []

def haversine_distance(lat1, lon1, lat2, lon2):
    R = 6371.0  # Earth radius in KM
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c

def safe_float(val, default=0.0):
    try:
        if val is None or str(val).strip() == "" or str(val).lower() == "nan":
            return default
        num = float(val)
        return num if not math.isnan(num) else default
    except Exception:
        return default

def classify_hotspots(df):
    if df is None or df.empty:
        return []

    facilities = load_facilities()
    classified_data = []

    for _, row in df.iterrows():
        try:
            lat = safe_float(row.get("latitude", row.get("lat")))
            lng = safe_float(row.get("longitude", row.get("lon", row.get("lng"))))
            if lat == 0.0 or lng == 0.0:
                continue

            frp = safe_float(row.get("frp"), default=5.0)

            # VIIRS/MODIS Brightness Fallback resolver
            brightness = safe_float(row.get("bright_ti4"))
            if brightness <= 0.0:
                brightness = safe_float(row.get("bright_ti5"))
            if brightness <= 0.0:
                brightness = safe_float(row.get("brightness"))
            if brightness <= 0.0:
                brightness = 310.0  # Default nominal thermal background

            acq_date = str(row.get("acq_date", "N/A"))
            acq_time = str(row.get("acq_time", "N/A"))

            matched_fac = None
            min_dist = float("inf")

            for fac in facilities:
                fac_lat = safe_float(fac.get("lat"))
                fac_lng = safe_float(fac.get("lng"))
                if fac_lat == 0.0 or fac_lng == 0.0:
                    continue

                dist = haversine_distance(lat, lng, fac_lat, fac_lng)
                buffer_dist = safe_float(fac.get("buffer_km"), default=4.5)

                if dist <= buffer_dist and dist < min_dist:
                    min_dist = dist
                    matched_fac = fac

            if matched_fac:
                baseline = safe_float(matched_fac.get("baseline_frp"), default=35.0)
                if frp > (baseline * 2.0) or brightness > 360.0:
                    label = f"Industrial Flare Spike / Anomaly @ {matched_fac['name']}"
                    severity = "CRITICAL"
                else:
                    label = f"Routine Industrial Thermal Activity @ {matched_fac['name']}"
                    severity = "LOW"

                classified_data.append({
                    "lat": lat,
                    "lng": lng,
                    "frp": round(frp, 2),
                    "brightness": round(brightness, 1),
                    "label": label,
                    "severity": severity,
                    "facility_name": matched_fac["name"],
                    "facility_type": matched_fac.get("type", "Industrial"),
                    "distance_km": round(min_dist, 2),
                    "date": acq_date,
                    "time": acq_time
                })
            else:
                if frp > 75.0 or brightness > 365.0:
                    label = "Intense Wildfire / Forest Blaze"
                    severity = "CRITICAL"
                elif frp > 15.0 or brightness > 325.0:
                    label = "Wildfire / Vegetation Fire"
                    severity = "MEDIUM"
                else:
                    label = "Low Intensity Crop / Surface Burning"
                    severity = "LOW"

                classified_data.append({
                    "lat": lat,
                    "lng": lng,
                    "frp": round(frp, 2),
                    "brightness": round(brightness, 1),
                    "label": label,
                    "severity": severity,
                    "facility_name": None,
                    "facility_type": "Open Terrain / Forest",
                    "distance_km": None,
                    "date": acq_date,
                    "time": acq_time
                })
        except Exception:
            continue

    return classified_data