import os
import requests
import pandas as pd
from io import StringIO
from dotenv import load_dotenv

load_dotenv()

MAP_KEY = os.getenv("FIRMS_MAP_KEY", "").strip()
BBOX = "68,6,97,37"
CACHE_FILE = os.path.join(os.path.dirname(__file__), "..", "data", "hotspots_backup.csv")

def fetch_firms_hotspots(day_range=5):
    if not MAP_KEY or len(MAP_KEY) < 20:
        print("[WARN] Valid FIRMS_MAP_KEY not found.")
        return load_cached_hotspots()

    sensors = ["VIIRS_NOAA20_NRT", "VIIRS_SNPP_NRT", "MODIS_NRT"]
    collected_frames = []

    for sensor in sensors:
        url = f"https://firms.modaps.eosdis.nasa.gov/api/area/csv/{MAP_KEY}/{sensor}/{BBOX}/{day_range}"
        try:
            print(f"[INFO] Fetching {day_range}-day data from NASA FIRMS ({sensor})...")
            response = requests.get(url, timeout=10)

            if response.status_code == 200:
                text_data = response.text.strip()
                if "Invalid MAP_KEY" not in text_data:
                    df = pd.read_csv(StringIO(text_data))
                    if not df.empty and "latitude" in df.columns:
                        df["sensor_source"] = sensor
                        collected_frames.append(df)
        except Exception as e:
            print(f"[WARN] Connection to NASA ({sensor}) failed: {e}")
            continue

    if collected_frames:
        combined_df = pd.concat(collected_frames, ignore_index=True)
        if "bright_ti4" not in combined_df.columns and "brightness" in combined_df.columns:
            combined_df["bright_ti4"] = combined_df["brightness"]
        if "frp" not in combined_df.columns:
            combined_df["frp"] = 5.0

        combined_df = combined_df.drop_duplicates(subset=["latitude", "longitude", "acq_date"])
        # Save local backup for offline presentation
        os.makedirs(os.path.dirname(CACHE_FILE), exist_ok=True)
        combined_df.to_csv(CACHE_FILE, index=False)
        print(f"[SUCCESS] Fetched & cached {len(combined_df)} points.")
        return combined_df

    print("[INFO] Fallback: Loading offline backup dataset...")
    return load_cached_hotspots()

def load_cached_hotspots():
    if os.path.exists(CACHE_FILE):
        return pd.read_csv(CACHE_FILE)
    return pd.DataFrame()